# List of packages to load
packages <- c(
  "Seurat", "harmony", "stringr",
  "BiocParallel", "BiocGenerics",
  "nloptr", "edgeR","remote"
)

# Standard (built-in) packages: load directly
standard_pkgs <- c("stats", "parallel", "MASS")

# Install missing packages (CRAN/Bioconductor)
install_if_missing <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    message(paste("Installing package:", pkg))
    if (pkg %in% rownames(installed.packages())) return()
    
    # Try CRAN first
    tryCatch({
      install.packages(pkg)
    }, error = function(e) {
      # If CRAN fails, try Bioconductor
      if (!requireNamespace("BiocManager", quietly = TRUE)) {
        install.packages("BiocManager")
      }
      BiocManager::install(pkg, ask = FALSE)
    })
  }
}

# Check and install for non-standard packages
for (pkg in packages) {
  install_if_missing(pkg)
  library(pkg, character.only = TRUE)
}

# Load standard packages directly
for (pkg in standard_pkgs) {
  library(pkg, character.only = TRUE)
}

# Install FS4Clustering from github

if (!requireNamespace("FS4Clustering", quietly = TRUE)) {
  message(paste("Installing package:", "FS4Clustering"))
  if ("FS4Clustering" %in% rownames(installed.packages())) return()
  # Try CRAN first
  tryCatch({
    remotes::install_github("wangch156/FS4Clustering")
  }, error = function(e) {
    print(e)
  })
}

library(FS4Clustering)
